<?PHP
//	ヘッダ

	include("./sub/array.inc");
	include("./sub/head.inc");

	$headmsg = headmsg();

	echo($headmsg);

	exit;

?>
