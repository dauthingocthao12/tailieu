<?PHP
/*

	動画設定ファイル

	

*/

//	ナノスタッド　３Dパズル
//$MOVIE_LIST[1][R] = "<script src=\"http://stream.cms.rakuten.co.jp/gate/play/?w=320&h=286&mid=1341039&shop_id=217707&vid=846269269002&pt=0&cmid=1&bkt=&cl1=&cl2=&cl3=&cl4=&did=\" type=\"text/javascript\"></script>";	//	del ohkawara 2017/12/11
$MOVIE_LIST[1][R] = "<script src=\"//stream.cms.rakuten.co.jp/gate/play/?w=320&h=286&mid=1101341039&vid=846269269002\" type=\"text/javascript\"></script>";	//	add ohkawara 2017/12/11
$MOVIE_LIST[1][Y] = "<!--Y youtube:vid=V_9VpY5c08A -->";














?>