<?PHP
/*

	送料無料商品設定ファイル

	$SOURYOU_MURYOU['code'] = "商品名";
	codeの所に商品番号を入力する。
	他は共通

*/


$SOURYOU_MURYOU['LSE1504-25-2P'] = "ロット/ストッキング/25-27cm/2足セット";
$SOURYOU_MURYOU['LSE1504-22-2P'] = "ロット/ジュニア用ストッキング/22-24cm/2足セット";





?>